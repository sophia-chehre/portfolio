MUNICIPAL BUILDING EXPLORER — LOCAL REVIEW PACKAGE

Two explicitly bounded study windows in Bochum and Witten, not whole-city inventories.
Analysis: ETRS89 / UTM32 (EPSG:25832). Open the .qgs next to the GeoPackage.

Sources: Geobasis NRW / ALKIS and DVG; © OpenStreetMap contributors (ODbL); Microsoft Global ML Building Footprints (ODbL). See source manifest and METHOD.md for dates, semantics and limitations.
Code and source-data licences must be retained/confirmed before public redistribution.
