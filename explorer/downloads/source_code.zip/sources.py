"""Public source acquisition with cache, provenance and explicit CRS handling."""
from __future__ import annotations
import csv,gzip,hashlib,io,json,math,re,time
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlencode
import xml.etree.ElementTree as ET
import requests
import geopandas as gpd
from pyproj import Transformer
from shapely.geometry import Polygon,MultiPolygon,LineString,box,shape
from shapely.ops import polygonize,unary_union

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'data/raw';META=ROOT/'data/metadata'
HEADERS={'User-Agent':'MunicipalBuildingExplorer/1.0 (independent open-data portfolio research)'}
WFS='https://www.wfs.nrw.de/geobasis/wfs_nw_alkis_vereinfacht'
DVG='https://www.wfs.nrw.de/geobasis/wfs_nw_dvg'
GML='{http://www.opengis.net/gml/3.2}'
WINDOWS=[{'id':'bochum_langendreer','name':'Bochum','ags':'05911000','admin_type':'Kreisfreie Stadt',
          'district':'Kreisfreie Stadt Bochum','centre':[7.294,51.478],'half_width_m':1000},
         {'id':'witten','name':'Witten','ags':'05954036','admin_type':'Kreisangehörige Stadt',
          'district':'Ennepe-Ruhr-Kreis','centre':[7.335,51.4385],'half_width_m':1000}]
MANIFEST=[]

def fetch(url,path,post=None,timeout=100):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():
        last=None
        for attempt in range(3):
            try:
                r=requests.post(url,data=post,headers=HEADERS,timeout=timeout) if post else requests.get(url,headers=HEADERS,timeout=timeout)
                r.raise_for_status();data=r.content
                if not data:raise ValueError('Empty response')
                path.write_bytes(data)
                (path.with_suffix(path.suffix+'.provenance.json')).write_text(json.dumps({
                    'url':url,'post':post,'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),
                    'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)},indent=2),encoding='utf-8')
                break
            except (requests.RequestException,ValueError) as e:
                last=e;time.sleep(attempt+1)
        else:raise RuntimeError(f'Could not retrieve {url}: {last}')
    provenance=path.with_suffix(path.suffix+'.provenance.json')
    record=json.loads(provenance.read_text()) if provenance.exists() else {'url':url,'retrieved_at_utc':'prior metadata probe'}
    record.update({'file':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
    MANIFEST.append(record)
    return path.read_bytes()

def window_geometry(window,pad=0):
    x,y=Transformer.from_crs(4326,25832,always_xy=True).transform(*window['centre'])
    h=window['half_width_m']+pad
    return box(x-h,y-h,x+h,y+h)

def bbox_param(window,pad=100):
    return ','.join(str(v) for v in window_geometry(window,pad).bounds)+',urn:ogc:def:crs:EPSG::25832'

def parse_gml(data):
    root=ET.fromstring(data)
    if root.tag.endswith('ExceptionReport'):raise ValueError(ET.tostring(root,encoding='unicode')[:500])
    rows=[]
    for member in root.findall('{http://www.opengis.net/wfs/2.0}member'):
        obj=next(iter(member));props={c.tag.rsplit('}',1)[-1]:c.text for c in obj if len(c)==0}
        polygons=[]
        for pg in obj.iter(GML+'Polygon'):
            rings=[]
            for typ in ['exterior','interior']:
                for part in pg.findall(GML+typ):
                    pl=part.find('.//'+GML+'posList')
                    if pl is None or not pl.text:continue
                    nums=[float(n) for n in pl.text.split()]
                    dim=int(pl.get('srsDimension','2'))
                    rings.append([(nums[i],nums[i+1]) for i in range(0,len(nums),dim)])
            if rings and len(rings[0])>=4:polygons.append(Polygon(rings[0],rings[1:]))
        if polygons:
            rows.append({'source_id':props.get('oid') or obj.get(GML+'id'),
                         'object_code':(props.get('gfkzshh') or 'unknown').split('_')[0],
                         'building_type':props.get('funktion') or props.get('art') or 'ALKIS building/structure',
                         'updated':props.get('aktualit','unknown'),
                         'geometry':polygons[0] if len(polygons)==1 else MultiPolygon(polygons)})
    return gpd.GeoDataFrame(rows,geometry='geometry',crs='EPSG:25832'),root.attrib

def official(window):
    frames=[]
    for page in range(30):
        params={'service':'WFS','version':'2.0.0','request':'GetFeature','typeNames':'ave:GebaeudeBauwerk',
                'count':5000,'startIndex':page*5000,'sortBy':'oid','srsName':'EPSG:25832','bbox':bbox_param(window)}
        data=fetch(WFS+'?'+urlencode(params),RAW/f'{window["id"]}_official_{page}.gml')
        frame,meta=parse_gml(data)
        print(f'{window["id"]} official page {page}: {len(frame)}',flush=True)
        frames.append(frame)
        if int(meta.get('numberReturned',len(frame)))<5000:break
    else:raise RuntimeError('Official pagination safety limit reached')
    import pandas as pd
    out=gpd.GeoDataFrame(pd.concat(frames,ignore_index=True),geometry='geometry',crs='EPSG:25832')
    if out.source_id.duplicated().any():raise RuntimeError('Repeated official source IDs: check pagination')
    selected=out[out.object_code=='31001'].copy()
    (META/f'{window["id"]}_official_selection.json').write_text(json.dumps({
        'returned_buildings_and_structures':len(out),'retained_AX_Gebaeude_31001':len(selected),
        'excluded_parts_and_other_structures':len(out)-len(selected),
        'definition':'Only ALKIS AX_Gebaeude (object code 31001); exclude Bauteil and non-building planar structures.'},indent=2),encoding='utf-8')
    print(f'{window["id"]} official building selection: {len(selected)} of {len(out)}',flush=True)
    return selected

def municipality(window):
    params={'service':'WFS','version':'2.0.0','request':'GetFeature','typeNames':'dvg:nw_dvg1_gem','count':100,
            'srsName':'EPSG:25832','bbox':bbox_param(window),'outputFormat':'application/json; subtype=geojson'}
    data=json.loads(fetch(DVG+'?'+urlencode(params),RAW/f'{window["id"]}_municipality.geojson'))
    features=[f for f in data['features'] if str(f['properties'].get('KN','')).zfill(8)==window['ags']]
    if len(features)!=1:raise ValueError('Municipality key did not identify exactly one boundary')
    g=gpd.GeoDataFrame.from_features(features,crs='EPSG:25832')
    if not g.geometry.iloc[0].covers(window_geometry(window)):
        raise ValueError('Study window crosses selected municipality boundary')
    return g

def osm(window):
    bbox=gpd.GeoSeries([window_geometry(window,100)],crs=25832).to_crs(4326).total_bounds
    west,south,east,north=bbox
    coords=f'{south},{west},{north},{east}'
    query=f'[out:json][timeout:100];(way["building"]["building"!="no"]({coords});relation["building"]["type"="multipolygon"]({coords}););out geom;'
    path=RAW/f'{window["id"]}_osm.json'
    errors=[]
    for endpoint in ['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter']:
        try:
            data=json.loads(fetch(endpoint,path,post={'data':query},timeout=130));break
        except Exception as e:errors.append(str(e))
    else:raise RuntimeError('OSM query failed: '+'; '.join(errors))
    if 'remark' in data:raise RuntimeError('Overpass returned a partial/error response: '+data['remark'])
    relation_members={m['ref'] for el in data['elements'] if el['type']=='relation' for m in el.get('members',[]) if m['type']=='way'}
    rows=[];skipped=0
    for el in data['elements']:
        geom=None
        if el['type']=='way':
            if el['id'] in relation_members:continue
            coords=[(p['lon'],p['lat']) for p in el.get('geometry',[])]
            if len(coords)>=4 and coords[0]==coords[-1]:geom=Polygon(coords)
        else:
            outer=[];inner=[]
            for member in el.get('members',[]):
                coords=[(p['lon'],p['lat']) for p in member.get('geometry',[])]
                if len(coords)>=2:(inner if member.get('role')=='inner' else outer).append(LineString(coords))
            try:
                geom=unary_union(list(polygonize(unary_union(outer))))
                if inner:geom=geom.difference(unary_union(list(polygonize(unary_union(inner)))))
            except Exception:geom=None
        if geom is None or geom.is_empty:skipped+=1;continue
        rows.append({'source_id':f'{el["type"]}/{el["id"]}',
                     'building_type':el.get('tags',{}).get('building','yes'),'geometry':geom})
    print(f'{window["id"]} OSM parsed {len(rows)}, skipped {skipped}',flush=True)
    if skipped:raise ValueError(f'{skipped} OSM building objects could not be reconstructed; inspect before continuing')
    return gpd.GeoDataFrame(rows,columns=['source_id','building_type','geometry'],geometry='geometry',crs=4326)

def quadkey(lon,lat,z=9):
    x=int((lon+180)/360*(1<<z));y=int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*(1<<z))
    return ''.join(str((1 if x&(1<<i) else 0)+(2 if y&(1<<i) else 0)) for i in range(z-1,-1,-1))

def microsoft(window):
    readme_path=META/'microsoft_readme.txt'
    readme=fetch('https://raw.githubusercontent.com/microsoft/GlobalMLBuildingFootprints/main/README.md',readme_path).decode()
    csv_url=re.search(r'https://[^\s)]+/dataset-links.csv',readme).group(0)
    table=fetch(csv_url,META/'microsoft_dataset_links.csv').decode('utf-8-sig')
    bounds=gpd.GeoSeries([window_geometry(window,100)],crs=25832).to_crs(4326).total_bounds
    keys={quadkey(x,y) for x in (bounds[0],bounds[2]) for y in (bounds[1],bounds[3])}
    links=[row for row in csv.DictReader(io.StringIO(table)) if row.get('Location','').lower()=='germany' and row.get('QuadKey','').zfill(9) in keys]
    if not links:raise ValueError('No Microsoft tile for the selected German window')
    rows=[];envelope=box(*bounds)
    for row in links:
        key=row['QuadKey']; data=fetch(row['Url'],RAW/f'microsoft_{key}.geojsonl.gz',timeout=150)
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
            for number,line in enumerate(stream):
                feature=json.loads(line);geom=shape(feature['geometry'])
                if geom.intersects(envelope):rows.append({'source_id':f'ms/{key}/{number}',
                    'building_type':'ML-derived roof outline','geometry':geom})
        print(f'Microsoft tile {key} selected {len(rows)} candidate outlines',flush=True)
    return gpd.GeoDataFrame(rows,columns=['source_id','building_type','geometry'],geometry='geometry',crs=4326)

def get_layers(window):
    return {'official':official(window),'osm':osm(window),'microsoft':microsoft(window)},municipality(window)

def save_manifest():
    META.mkdir(parents=True,exist_ok=True)
    prior=META/'sources_manifest.json'
    unique={x['file']:x for x in json.loads(prior.read_text())} if prior.exists() else {}
    unique.update({x['file']:x for x in MANIFEST})
    (META/'sources_manifest.json').write_text(json.dumps(list(unique.values()),indent=2),encoding='utf-8')
