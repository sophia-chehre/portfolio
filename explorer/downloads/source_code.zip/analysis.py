"""Projected, deterministic footprint comparison. No confidential inputs."""
from __future__ import annotations
from collections import defaultdict
import math
import geopandas as gpd
import numpy as np
from shapely import make_valid, union_all
from shapely.geometry import box

CRS = 'EPSG:25832'

def municipality_key(value):
    value = str(value).strip()
    if value.endswith('.0'):
        value = value[:-2]
    if not value.isdigit() or len(value) > 8:
        raise ValueError('A municipality key must contain at most eight digits')
    return value.zfill(8)

def normalise(frame, window, source, ags):
    """Keep complete polygons whose representative point falls in the window."""
    if frame.crs is None:
        raise ValueError('Input CRS is required')
    if 'source_id' not in frame:
        raise ValueError('Stable source IDs are required')
    frame = frame.to_crs(CRS).copy()
    report = {'input_count':len(frame), 'repaired_geometries':0, 'dropped_nonpolygon':0,
              'dropped_duplicates':0, 'outside_window':0}
    rows, seen = [], set()
    for _, row in frame.sort_values('source_id').iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            report['dropped_nonpolygon'] += 1; continue
        if not geom.is_valid:
            geom = make_valid(geom); report['repaired_geometries'] += 1
        if geom.geom_type == 'GeometryCollection':
            geom = union_all([p for p in geom.geoms if p.geom_type in ('Polygon','MultiPolygon')])
        if geom.geom_type not in ('Polygon','MultiPolygon') or geom.area < 1:
            report['dropped_nonpolygon'] += 1; continue
        key = geom.normalize().wkb
        if key in seen:
            report['dropped_duplicates'] += 1; continue
        seen.add(key)
        if not window.covers(geom.representative_point()):
            report['outside_window'] += 1; continue
        rows.append({'source_id':str(row.source_id), 'source':source,
                     'municipality_ags':municipality_key(ags),
                     'building_type':str(row.get('building_type','not specified')),
                     'area_m2':round(geom.area,3), 'geometry':geom})
    columns=['source_id','source','municipality_ags','building_type','area_m2','geometry']
    out = gpd.GeoDataFrame(rows, columns=columns, geometry='geometry', crs=CRS)
    report['selected_count'] = len(out)
    return out.reset_index(drop=True), report

def compare(reference, candidate, threshold=.5):
    """Report overlap agreement, not unqualified truth/accuracy.

    Exact IoU is calculated for every intersecting pair. Multiple source outlines
    may correspond to one reference; counts use unique IDs, not pair counts.
    Lower-IoU overlaps are review cases, never automatically called missing.
    """
    if not 0 < threshold <= 1:
        raise ValueError('IoU threshold must be in (0, 1]')
    if reference.crs is None or candidate.crs is None or not reference.crs.equals(candidate.crs):
        raise ValueError('Reference and candidate must share a projected CRS')
    if reference.crs.is_geographic:
        raise ValueError('Area comparison requires projected coordinates')
    pairs=[]; ref_pairs=defaultdict(list); candidate_pairs=defaultdict(list)
    index=reference.sindex
    for ci, cgeom in enumerate(candidate.geometry):
        for ri in index.query(cgeom, predicate='intersects'):
            rgeom=reference.geometry.iloc[int(ri)]
            intersection=cgeom.intersection(rgeom).area
            if intersection <= 0:
                continue
            iou=intersection/(cgeom.area+rgeom.area-intersection)
            pair={'reference_index':int(ri),'candidate_index':ci,'iou':float(iou),
                  'reference_fraction':intersection/rgeom.area,
                  'candidate_fraction':intersection/cgeom.area}
            pairs.append(pair); ref_pairs[int(ri)].append(pair); candidate_pairs[ci].append(pair)
    result=candidate.copy(); annotated=[]
    for ci,row in candidate.iterrows():
        pp=sorted(candidate_pairs[ci],key=lambda p:(-p['iou'],p['reference_index']))
        best=pp[0] if pp else None
        strong=[p for p in pp if min(p['reference_fraction'],p['candidate_fraction'])>=.2
                or max(p['reference_fraction'],p['candidate_fraction'])>=.8]
        split_merge=len(strong)>1 or any(len([q for q in ref_pairs[p['reference_index']]
            if max(q['reference_fraction'],q['candidate_fraction'])>=.8])>1 for p in strong)
        status='overlap_match' if best and best['iou']>=threshold else ('review_overlap' if best else 'unpaired')
        annotated.append({'comparison_status':status, 'best_iou':round(best['iou'],4) if best else 0.,
            'reference_id':str(reference.source_id.iloc[best['reference_index']]) if best else '',
            'split_merge_review':bool(split_merge)})
    for col in ['comparison_status','best_iou','reference_id','split_merge_review']:
        result[col]=[a[col] for a in annotated]
    ref_result=reference.copy()
    ref_result['comparison_status']=[
        'overlap_match' if any(p['iou']>=threshold for p in ref_pairs[i])
        else ('review_overlap' if ref_pairs[i] else 'unpaired') for i in range(len(reference))]
    ref_result['best_iou']=[max([p['iou'] for p in ref_pairs[i]],default=0.) for i in range(len(reference))]
    rc=ref_result.comparison_status.value_counts().to_dict()
    cc=result.comparison_status.value_counts().to_dict()
    ref_area=float(reference.geometry.area.sum()); cand_area=float(candidate.geometry.area.sum())
    summary={'reference_features':len(reference),'candidate_features':len(candidate),
             'reference_overlap_matched':rc.get('overlap_match',0),
             'reference_review_overlap':rc.get('review_overlap',0),'reference_unpaired':rc.get('unpaired',0),
             'candidate_overlap_matched':cc.get('overlap_match',0),
             'candidate_review_overlap':cc.get('review_overlap',0),'candidate_unpaired':cc.get('unpaired',0),
             'split_merge_review':int(result.split_merge_review.sum()),
             'reference_area_m2':round(ref_area,1),'candidate_area_m2':round(cand_area,1),
             'area_difference_pct':round((cand_area-ref_area)/ref_area*100,2) if ref_area else None,
             'reference_overlap_match_pct':round(rc.get('overlap_match',0)/len(reference)*100,2) if len(reference) else None,
             'iou_threshold':threshold,
             'sensitivity':{str(t):len({p['reference_index'] for p in pairs if p['iou']>=t}) for t in [.25,.5,.75]}}
    return result,ref_result,summary

def grid_summary(reference,candidate,window,cell_size=200):
    minx,miny,maxx,maxy=window.bounds
    x0=math.floor(minx/cell_size)*cell_size; y0=math.floor(miny/cell_size)*cell_size
    rp=reference.geometry.representative_point(); cp=candidate.geometry.representative_point()
    rows=[]
    for x in np.arange(x0,maxx,cell_size):
        for y in np.arange(y0,maxy,cell_size):
            geom=box(x,y,x+cell_size,y+cell_size).intersection(window)
            if geom.is_empty or geom.area<1: continue
            # Half-open coordinate bins avoid double-counting points on a grid edge.
            rr=((rp.x>=x)&(rp.x<x+cell_size)&(rp.y>=y)&(rp.y<y+cell_size))
            cr=((cp.x>=x)&(cp.x<x+cell_size)&(cp.y>=y)&(cp.y<y+cell_size))
            rn=int(rr.sum());cn=int(cr.sum())
            rows.append({'cell_id':f'{int(x)}_{int(y)}','reference_count':rn,'candidate_count':cn,
                         'count_difference':cn-rn,'geometry':geom})
    return gpd.GeoDataFrame(rows,crs=CRS)
