from pathlib import Path
from sources import WINDOWS,get_layers,save_manifest

if __name__=='__main__':
    cache=Path(__file__).resolve().parent/'data/cache'
    cache.mkdir(parents=True,exist_ok=True)
    for window in WINDOWS:
        if all((cache/f'{window["id"]}_{name}.gpkg').exists() for name in ['official','osm','microsoft','boundary']):
            print(window['id'],'cached',flush=True);continue
        layers,boundary=get_layers(window)
        for name,frame in layers.items():
            frame.to_file(cache/f'{window["id"]}_{name}.gpkg',driver='GPKG')
        boundary.to_file(cache/f'{window["id"]}_boundary.gpkg',driver='GPKG')
        save_manifest()
    save_manifest()
