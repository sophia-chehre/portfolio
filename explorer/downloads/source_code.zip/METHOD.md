# Method and interpretation

## Scope and selection

Two 2 × 2 km projected windows, not whole municipalities: Bochum-Langendreer (centre 7.294 E, 51.478 N; AGS 05911000) and central Witten (7.335 E, 51.4385 N; AGS 05954036). Bochum is a kreisfreie Stadt; Witten is a kreisangehörige Stadt in Ennepe-Ruhr-Kreis. DVG1 municipal boundaries verify window containment and preserve the eight-digit municipality key as text.

An initial central-Bochum probe (7.2165 E, 51.4818 N) returned no Microsoft outlines in the selected tile. The study window was moved east to Langendreer to make a three-source comparison possible. This is a deliberate coverage-based selection, not a representative sample of either municipality or of model quality. The initial probe is retained as acquisition material, not included in final analytical counts. It establishes a dataset coverage gap, not absence of buildings. The README-derived Microsoft release is 13 August 2026; imagery dates differ and are not inferred from release date.

## Harmonisation

The official simplified ALKIS WFS contains building parts and other structures. Retain only AX_Gebaeude (31001). Page complete results, repair polygon geometry where possible, remove exact normalised-geometry duplicates, and select whole geometries whose representative point falls in each window. Do not clip them for area calculation. OSM ways and multipolygon relations are reconstructed, excluding duplicate relation member ways. Model-derived outlines come directly from Microsoft, not a mixed-source Overture layer.

Analysis uses ETRS89 / UTM zone 32N (EPSG:25832), including all area and distance calculations. Web output uses EPSG:4326, with light simplification (0.000001 degrees) and six-decimal rounding only for display. Reported areas sum selected footprints; they do not describe floor area, legal development potential or sealed land area.

## Agreement and review

For each intersecting candidate/reference pair, compute intersection area divided by union area (IoU). A pair at or above 0.5 is an overlap match. Report unique matched reference objects; multiple candidate matches do not increase the reference denominator. A candidate with overlap below 0.5 is a review case; one with no intersection is unpaired. Intersections with several reference features and reference features intersected by several candidates flag potential split/merge cases. This flag does not resolve semantic building identity.

Threshold sensitivity is reported at 0.25, 0.5 and 0.75. The 200 m grid counts representative points once using half-open allocation; cells are analytical units, not official districts. The dated official layer is a reference, not infallible ground truth. Differences in roof versus ground outlines, dates, definitions, omissions and geometry grouping can all explain disagreements. No causal explanation or independent model accuracy is claimed.

## Verification

Synthetic analytical tests cover exact matches, unpaired features, split geometries, duplicate shapes, invalid polygons, CRS handling, empty sources, leading-zero keys, grid-edge allocation and threshold monotonicity. Each generated GIS layer is re-opened and checked for EPSG:25832 and valid geometry. Source and code hashes and selection QA accompany the results. Browser checks are recorded separately after the build.
