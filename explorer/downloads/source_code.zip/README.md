# Municipal Building Explorer

An independent, public-data project by Sophia Chehreghan. It demonstrates a municipal GIS workflow: source acquisition, German administrative keys, geometry QA, spatial comparison and delivery as an interactive map and GIS package. It does not reuse confidential employer files.

## Run locally

Use Python 3.11 or later in a virtual environment. Install `requirements.txt`, run `python acquire.py`, then `python run.py`. Run `python -m pytest tests -q` for analytical checks. Serve `app/` over HTTP, for example `python -m http.server 8765 --directory app`, and open localhost:8765. Network access is required for first acquisition and the optional basemap. The footprint comparison itself uses local cached data.

Acquisition caches responses and URL, time, byte count and SHA-256 provenance. To acquire a new snapshot, use a separate empty data directory/version; existing caches are intentionally reused. A build is reproducible from the retained snapshot, not from a promise that live services will never change.

## Deliverables

- `app/`: interactive local map, data and downloads.
- `outputs/municipal_buildings.gpkg`: full projected geometries, evaluations, grids and boundaries.
- `outputs/Municipal_Building_Explorer.qgs`: relative-path QGIS starter project. Generated XML and layer references are checked; opening in desktop QGIS requires a separate visual check.
- `outputs/comparison_summary.csv`, matching tables and `qa_report.json`.
- `outputs/run_manifest.json`: source and code hashes, parameters and QA.
- `METHOD.md`: definitions, selection rationale and limitations.
- `INTERVIEW_GUIDE_FA.md`: Persian explanation of the actual workflow.

## Sources and reuse

ALKIS and DVG: Geobasis NRW, Data licence Germany Zero 2.0. OpenStreetMap: © OpenStreetMap contributors, ODbL 1.0. Microsoft Global ML Building Footprints: ODbL 1.0. Leaflet 1.9.4 retains its bundled licence. The GIS download retains source attribution and provenance; derived database reuse is subject to ODbL obligations. Original code has no public reuse licence selected yet. Local review does not publish this project.
