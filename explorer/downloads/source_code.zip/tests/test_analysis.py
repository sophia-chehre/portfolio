import geopandas as gpd
import pytest
from shapely.geometry import box,Polygon
from analysis import compare,normalise,municipality_key,grid_summary

def frame(geoms,ids=None,crs='EPSG:25832'):
    return gpd.GeoDataFrame({'source_id':ids or [str(i) for i in range(len(geoms))]},geometry=geoms,crs=crs)

def test_ags_preserves_leading_zero():
    assert municipality_key('5911000')=='05911000'
    assert municipality_key('05954036')=='05954036'
    with pytest.raises(ValueError):municipality_key('Bochum')

def test_exact_match_and_unpaired_counts():
    r=frame([box(0,0,10,10),box(20,0,30,10)])
    c=frame([box(0,0,10,10),box(50,0,60,10)])
    out,ref,s=compare(r,c)
    assert list(out.comparison_status)==['overlap_match','unpaired']
    assert s['reference_overlap_matched']==1 and s['reference_unpaired']==1
    assert s['reference_overlap_match_pct']==50

def test_split_building_is_review_not_missing_and_not_double_counted():
    r=frame([box(0,0,10,10)])
    c=frame([box(0,0,3,10),box(3,0,6,10),box(6,0,10,10)])
    out,ref,s=compare(r,c)
    assert s['reference_features']==1 and s['reference_review_overlap']==1
    assert s['reference_unpaired']==0
    assert out.split_merge_review.all()

def test_many_candidates_never_inflate_reference_matches():
    r=frame([box(0,0,10,10)])
    c=frame([box(0,0,10,10),box(0,0,10,9)])
    assert compare(r,c)[2]['reference_overlap_matched']==1

def test_source_geometry_is_not_clipped_for_area():
    raw=frame([box(-5,-5,5,5)])
    out,qa=normalise(raw,box(-1,-1,2,2),'official','05911000')
    assert len(out)==1 and out.area_m2.iloc[0]==100

def test_duplicate_shapes_removed_and_invalid_geometry_repaired():
    raw=frame([box(0,0,10,10),box(0,0,10,10),Polygon([(20,0),(30,10),(20,10),(30,0),(20,0)])])
    out,qa=normalise(raw,box(-50,-50,50,50),'official','05911000')
    assert len(out)==2 and qa['dropped_duplicates']==1 and qa['repaired_geometries']==1
    assert out.is_valid.all()

def test_geographic_area_comparison_rejected():
    r=frame([box(0,0,1,1)],crs='EPSG:4326')
    with pytest.raises(ValueError):compare(r,r)

def test_unknown_crs_rejected():
    with pytest.raises(ValueError):normalise(frame([box(0,0,2,2)],crs=None),box(0,0,10,10),'osm','05911000')

def test_empty_candidate_and_empty_reference_are_explicit():
    r=frame([box(0,0,10,10)]);empty=frame([])
    out,ref,s=compare(r,empty)
    assert s['reference_unpaired']==1 and s['candidate_features']==0
    assert compare(empty,empty)[2]['reference_overlap_match_pct'] is None

def test_grid_point_on_edge_counted_once():
    r=frame([box(9,4,11,6)])
    grid=grid_summary(r,r,box(0,0,20,10),cell_size=10)
    assert grid.reference_count.sum()==1 and grid.candidate_count.sum()==1

def test_sensitivity_monotonic():
    r=frame([box(0,0,10,10)]);c=frame([box(2,0,12,10)])
    sensitivity=compare(r,c)[2]['sensitivity']
    assert sensitivity['0.25']>=sensitivity['0.5']>=sensitivity['0.75']
