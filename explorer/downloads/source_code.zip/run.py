"""Build the real-data comparison, GIS deliverables and static application data."""
from pathlib import Path
import json,hashlib,platform,zipfile,sys
from datetime import datetime,timezone
import geopandas as gpd
import pandas as pd
from shapely.geometry import mapping
from analysis import normalise,compare,grid_summary
from sources import WINDOWS,window_geometry

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs';APP=ROOT/'app';DATA=APP/'data'
SOURCES={
 'official':{'label':'Official · ALKIS NRW','short':'ALKIS','colour':'#3866a7',
  'url':'https://www.wfs.nrw.de/geobasis/wfs_nw_alkis_vereinfacht',
  'credit':'Geobasis NRW / ALKIS','licence':'Data licence Germany — Zero 2.0',
  'date_note':'Retrieved October 2026; selected AX_Gebaeude (31001) only. Object update dates vary; building parts and other structures excluded.'},
 'osm':{'label':'Community · OpenStreetMap','short':'OSM','colour':'#b5782c',
  'url':'https://www.openstreetmap.org/copyright','credit':'© OpenStreetMap contributors','licence':'ODbL 1.0',
  'date_note':'Live Overpass snapshot retrieved for this run; edit time is not necessarily observation time.'},
 'microsoft':{'label':'Model-derived · Microsoft','short':'Microsoft ML','colour':'#19877e',
  'url':'https://github.com/microsoft/GlobalMLBuildingFootprints','credit':'Microsoft Global ML Building Footprints',
  'licence':'ODbL 1.0','date_note':'Global release 13 August 2026; imagery dates vary. Model-derived roof outlines, not model training by this project.'}}

def write_json(path,data):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')

def web_geojson(frame,path):
 out=frame.to_crs(4326).copy()
 out.geometry=out.geometry.simplify(.000001,preserve_topology=True)
 features=[]
 def rounded(v):
  if isinstance(v,(list,tuple)):return [rounded(x) for x in v]
  return round(v,6) if isinstance(v,float) else v
 for _,row in out.iterrows():
  props={k:None if pd.isna(v) else (v.item() if hasattr(v,'item') else v) for k,v in row.items() if k!='geometry'}
  geom=mapping(row.geometry)
  features.append({'type':'Feature','properties':props,'geometry':{'type':geom['type'],'coordinates':rounded(geom['coordinates'])}})
 write_json(path,{'type':'FeatureCollection','features':features})

def qgis_project(layers,bounds):
 import xml.etree.ElementTree as ET
 q=ET.Element('qgis',{'version':'3.34.0','projectname':'Municipal Building Explorer — Bochum & Witten'})
 tree=ET.SubElement(q,'layer-tree-group',{'name':'Municipal Building Explorer','checked':'Qt::Checked'})
 pls=ET.SubElement(q,'projectlayers')
 for layer,colour in layers:
  lid=layer.replace('-','_')+'_layer'
  ET.SubElement(tree,'layer-tree-layer',{'id':lid,'name':layer,'checked':'Qt::Checked','expanded':'0','providerKey':'ogr','source':f'./municipal_buildings.gpkg|layername={layer}'})
  ml=ET.SubElement(pls,'maplayer',{'type':'vector','geometry':'Polygon','hasScaleBasedVisibilityFlag':'0'})
  for key,value in [('id',lid),('layername',layer),('datasource',f'./municipal_buildings.gpkg|layername={layer}'),('provider','ogr')]:ET.SubElement(ml,key).text=value
  srs=ET.SubElement(ET.SubElement(ml,'srs'),'spatialrefsys')
  ET.SubElement(srs,'authid').text='EPSG:25832';ET.SubElement(srs,'description').text='ETRS89 / UTM zone 32N'
  renderer=ET.SubElement(ml,'renderer-v2',{'type':'singleSymbol','symbollevels':'0'})
  sy=ET.SubElement(ET.SubElement(renderer,'symbols'),'symbol',{'name':'0','type':'fill','alpha':'0.65'})
  sl=ET.SubElement(sy,'layer',{'class':'SimpleFill','enabled':'1'})
  opt=ET.SubElement(sl,'Option',{'type':'Map'})
  for key,value in [('color',colour),('outline_color',colour),('outline_width','0.15'),('outline_width_unit','MM')]:ET.SubElement(opt,'Option',{'name':key,'value':value,'type':'QString'})
 canvas=ET.SubElement(q,'mapcanvas');ext=ET.SubElement(canvas,'extent')
 for key,value in zip(['xmin','ymin','xmax','ymax'],bounds):ET.SubElement(ext,key).text=str(value)
 srs=ET.SubElement(ET.SubElement(canvas,'destinationsrs'),'spatialrefsys');ET.SubElement(srs,'authid').text='EPSG:25832'
 ET.SubElement(q,'title').text='Two 2 × 2 km study windows; not complete municipal inventories'
 ET.indent(q);ET.ElementTree(q).write(OUT/'Municipal_Building_Explorer.qgs',encoding='utf-8',xml_declaration=True)

def main():
 OUT.mkdir(exist_ok=True);DATA.mkdir(parents=True,exist_ok=True)
 cache=ROOT/'data/cache';metrics=[];qa={};windows=[];layers=[];allbounds=[]
 gpkg=OUT/'municipal_buildings.gpkg'
 if gpkg.exists():gpkg.unlink() # This script's own deterministic generated deliverable only.
 for w in WINDOWS:
  print('Processing',w['name'],flush=True)
  window=window_geometry(w);qa[w['id']]={};normal={}
  for source in SOURCES:
   raw=gpd.read_file(cache/f'{w["id"]}_{source}.gpkg')
   normal[source],qa[w['id']][source]=normalise(raw,window,source,w['ags'])
   normal[source]['window_id']=w['id']
   normal[source].to_file(gpkg,layer=f'{w["id"]}_{source}',driver='GPKG')
   layers.append((f'{w["id"]}_{source}',SOURCES[source]['colour']))
  ref=normal['official'].copy();ref['comparison_status']='reference';ref['best_iou']=None
  web_geojson(ref,DATA/f'{w["id"]}_official.geojson')
  comparisons={}
  for source in ['osm','microsoft']:
   candidate,reference,summary=compare(normal['official'],normal[source])
   candidate['window_id']=w['id'];reference['window_id']=w['id']
   comparisons[source]=summary
   metrics.append({'window':w['id'],'municipality':w['name'],'ags':w['ags'],'source':source,**{k:v for k,v in summary.items() if k!='sensitivity'}})
   web_geojson(candidate,DATA/f'{w["id"]}_{source}.geojson')
   web_geojson(reference,DATA/f'{w["id"]}_reference_{source}.geojson')
   candidate.to_file(gpkg,layer=f'{w["id"]}_{source}_evaluated',driver='GPKG')
   layers.append((f'{w["id"]}_{source}_evaluated',SOURCES[source]['colour']))
   candidate.drop(columns='geometry').to_csv(OUT/f'{w["id"]}_{source}_matches.csv',index=False)
   grid=grid_summary(normal['official'],candidate,window)
   grid.to_file(gpkg,layer=f'{w["id"]}_{source}_grid',driver='GPKG')
   web_geojson(grid,DATA/f'{w["id"]}_{source}_grid.geojson')
   layers.append((f'{w["id"]}_{source}_grid','#8d799b'))
  boundary=gpd.read_file(cache/f'{w["id"]}_boundary.gpkg')
  if str(boundary.KN.iloc[0]).zfill(8)!=w['ags']:raise ValueError('Boundary/AGS inconsistency')
  boundary.to_file(gpkg,layer=f'{w["id"]}_municipality',driver='GPKG')
  layers.append((f'{w["id"]}_municipality','#596b7a'))
  web_geojson(boundary,DATA/f'{w["id"]}_municipality.geojson')
  wg=gpd.GeoDataFrame([{'window_id':w['id'],'municipality_ags':w['ags'],'geometry':window}],crs=25832)
  wg.to_file(gpkg,layer=f'{w["id"]}_study_window',driver='GPKG')
  layers.append((f'{w["id"]}_study_window','#e3a44b'))
  bounds=wg.to_crs(4326).total_bounds.tolist();allbounds.append(window.bounds)
  windows.append({**w,'study_area_km2':round(window.area/1e6,2),'bbox':bounds,
      'boundary_date':str(boundary.STAND.iloc[0]),'reference_features':len(ref),
      'source_counts':{s:len(normal[s]) for s in SOURCES},'comparisons':comparisons})
 pd.DataFrame(metrics).to_csv(OUT/'comparison_summary.csv',index=False)
 manifest_file=ROOT/'data/metadata/sources_manifest.json'
 manifest=json.loads(manifest_file.read_text()) if manifest_file.exists() else []
 catalog={'title':'Municipal Building Explorer','version':'1.0.0','built_at_utc':datetime.now(timezone.utc).isoformat(),
          'analysis_crs':'EPSG:25832','web_crs':'EPSG:4326','sources':SOURCES,'windows':windows,
          'method':{'iou_threshold':.5,'selection':'Full geometry retained; representative point inside the projected study window.',
                    'scope':'Two 2 × 2 km study windows. Counts are not complete-city counts.',
                    'interpretation':'Overlap agreement against a dated official reference, not unconditional model accuracy.',
                    'area':'Sum of complete selected polygon areas; not floor area, housing capacity or a land-use designation.',
                    'web_geometry':'Web display simplified at 0.000001 degrees and rounded to 6 decimals; analysis uses original projected geometry.'}}
 write_json(DATA/'catalog.json',catalog);write_json(OUT/'qa_report.json',qa)
 write_json(OUT/'run_manifest.json',{'built_at_utc':catalog['built_at_utc'],'python':platform.python_version(),
     'inputs':manifest,'code_sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['analysis.py','sources.py','run.py']},
     'parameters':catalog['method'],'qa':qa})
 bb=[min(b[0] for b in allbounds),min(b[1] for b in allbounds),max(b[2] for b in allbounds),max(b[3] for b in allbounds)]
 qgis_project(layers,bb)
 # Validation of the generated GIS package independently of the web export.
 for name,_ in layers:
  check=gpd.read_file(gpkg,layer=name)
  if check.crs.to_epsg()!=25832 or not check.geometry.is_valid.all():raise ValueError('Invalid GIS output '+name)
 print(pd.DataFrame(metrics)[['municipality','source','reference_features','candidate_features','reference_overlap_match_pct','candidate_unpaired']].to_string(index=False),flush=True)
 print('GIS package validated:',len(layers),'layers',flush=True)
 # Static figures use actual, computed data and retain explicit study-window scope.
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(1,2,figsize=(10,3.5),facecolor='#f5f4ee')
 for ax,w in zip(axes,windows):
  counts=w['source_counts'];ax.set_facecolor('#f5f4ee')
  ax.bar(['ALKIS','OSM','Microsoft ML'],list(counts.values()),color=[SOURCES[s]['colour'] for s in SOURCES],width=.6)
  ax.set_title(w['name']+' · 4 km² study window',loc='left',fontweight='bold');ax.set_ylabel('Selected outlines')
  for i,n in enumerate(counts.values()):ax.text(i,n+max(counts.values())*.02,f'{n:,}',ha='center',fontsize=9)
  ax.set_ylim(0,max(counts.values())*1.15)
 fig.tight_layout();fig.savefig(OUT/'source_comparison.svg',bbox_inches='tight');fig.savefig(OUT/'source_comparison.png',dpi=160,bbox_inches='tight');plt.close(fig)
 downloads=APP/'downloads';downloads.mkdir(exist_ok=True)
 for name in ['comparison_summary.csv','qa_report.json','source_comparison.svg','run_manifest.json']:
  import shutil;shutil.copy2(OUT/name,downloads/name)
 credits='''MUNICIPAL BUILDING EXPLORER — LOCAL REVIEW PACKAGE\n\nTwo explicitly bounded study windows in Bochum and Witten, not whole-city inventories.\nAnalysis: ETRS89 / UTM32 (EPSG:25832). Open the .qgs next to the GeoPackage.\n\nSources: Geobasis NRW / ALKIS and DVG; © OpenStreetMap contributors (ODbL); Microsoft Global ML Building Footprints (ODbL). See source manifest and METHOD.md for dates, semantics and limitations.\nCode and source-data licences must be retained/confirmed before public redistribution.\n'''
 (OUT/'PACKAGE_README.txt').write_text(credits,encoding='utf-8')
 with zipfile.ZipFile(downloads/'municipal_buildings_gis.zip','w',zipfile.ZIP_DEFLATED) as z:
  for name in ['municipal_buildings.gpkg','Municipal_Building_Explorer.qgs','comparison_summary.csv','qa_report.json','run_manifest.json','PACKAGE_README.txt']:
   z.write(OUT/name,name)
 print('Built real-data application payload and local GIS download.',flush=True)

if __name__=='__main__':main()
